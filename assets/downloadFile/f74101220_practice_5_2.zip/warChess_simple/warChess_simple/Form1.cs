﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace warChess_simple {
    public partial class Form1 : Form {

        public static Point standButton_offset = new Point(280, 100);
        public static string[] chessTypeName = new string[3] { "戰士", "法師", "遊俠" };

        Button[] standButton_arr = new Button[42];
        int timerCount_prepare = 10;
        // 1.worrier 2.wizard 3.ranger
        List<RadioButton> chess_prepare_p1 = new List<RadioButton>();
        List<RadioButton> chess_prepare_p2 = new List<RadioButton>();

        // row 0:player1 1:player2
        List<List<RadioButton>> chess_chooseButton_prepare_all = new List<List<RadioButton>>();

        bool player1_ed = false, player2_ed = false;
        // 0.player1 1.player2
        public static Color[] players_color = new Color[] { Color.LightBlue, Color.LightPink };
        public static Player[] players;
        Label[] choose_label;
        Label[] chessInfo;
        // row 0:player1 1:player2
        // 1.atk 2.move 3.skill 4.idle
        Button[,] battleInstructionButton;
        Button[] finishButton;
        string[] battle_title = new string[2] { "P1 Turn", "P2 Turn" };

        bool isPlayer1Battle = false;
        // 0.worrier 1.wizard 2.ranger
        int player_round = 0;

        public Form1() {
            InitializeComponent();

            chess_prepare_p1.Add(worriorButton_prepare_p1);
            chess_prepare_p1.Add(wizardButton_prepare_p1);
            chess_prepare_p1.Add(rangerButton_prepare_p1);

            chess_prepare_p2.Add(worriorButton_prepare_p2);
            chess_prepare_p2.Add(wizardButton_prepare_p2);
            chess_prepare_p2.Add(rangerButton_prepare_p2);

            chess_chooseButton_prepare_all.Add(chess_prepare_p1);
            chess_chooseButton_prepare_all.Add(chess_prepare_p2);

            choose_label = new Label[] { choose_label_p1, choose_label_p2 };

            chessInfo = new Label[] { chessInfo_p1, chessInfo_p2 };

            battleInstructionButton =
                new Button[2, 4] { {attackButton_p1, moveButton_p1, skillButton_p1, idleButton_p1 },
                                    { attackButton_p2, moveButton_p2, skillButton_p2, idleButton_p2} };

            finishButton = new Button[2] { finishButton_p1, finishButton_p2 };

            players = new Player[] { new Player(players_color[0], chessTypeName[0], chessTypeName[1], chessTypeName[2]),
                                        new Player(players_color[1], chessTypeName[0], chessTypeName[1], chessTypeName[2]) };
        }

        private void button1_Click(object sender, EventArgs e) {
            startButton.Enabled = false;
            startButton.Visible = false;

            title.Visible = true;
            timerLable.Visible = true;
            timerLable.Text = $"{timerCount_prepare}";

            player1_label.Visible = true;
            player2_label.Visible = true;

            choose_label[0].Visible = true;

            foreach (var b in chess_prepare_p1) {
                b.Visible = true;
                b.Enabled = true;
            }
            foreach (var b in chess_prepare_p2) {
                b.Visible = true;
            }

            worriorButton_prepare_p1.Checked = true;

            timerPrepare.Enabled = true;

            generate_Standbutton_arr();

        }

        private void Form1_Load(object sender, EventArgs e) {
            startButton.Enabled = true;
            startButton.Visible = true;

            title.Visible = false;
            timerLable.Visible = false;

            player1_label.Visible = false;
            player2_label.Visible = false;

            foreach (var l in choose_label) {
                l.Visible = false;
            }

            foreach (var b in chess_prepare_p1) {
                b.Visible = false;
                b.Enabled = false;
            }
            foreach (var b in chess_prepare_p2) {
                b.Visible = false;
                b.Enabled = false;
            }

            timerPrepare.Enabled = false;

            // battle item
            foreach (var l in chessInfo) {
                l.Visible = false;
            }
            foreach (Button b in battleInstructionButton) {
                b.Visible = false;
                b.Enabled = false;
            }

            foreach (var b in finishButton) {
                b.Visible = false;
                b.Enabled = false;
            }
        }

        private void Form1_Battle() {
            title.Text = battle_title[0];

            choose_label[1].Visible = false;

            for (int i = 0; i < chess_chooseButton_prepare_all.Count; i++) {
                foreach (var b in chess_chooseButton_prepare_all[i]) {
                    b.Enabled = false;
                    b.Visible = false;
                }
            }

            timerLable.Visible = false;

            foreach (var b in standButton_arr) {
                b.Enabled = true;
                b.Click += standButton_Click_battle;
            }
            for (int i = 0; i < chessInfo.Length; i++) {
                chessInfo[i].Visible = true;
            }
            choose_label[0].Text = "戰士";
            showChessInfo(0, 0);
            chessInfo[1].Visible = false;

            for (int i = 0; i < battleInstructionButton.GetLength(0); i++) {
                for (int j = 0; j < battleInstructionButton.GetLength(1); j++) {
                    if (i == 0) {
                        battleInstructionButton[i, j].Enabled = true;
                    }
                    else if (i == 1) {
                        battleInstructionButton[i, j].Enabled = false;
                    }
                    battleInstructionButton[i, j].Visible = true;
                }
            }

            isPlayer1Battle = true;
            foreach (var b in finishButton) {
                b.Visible = true;
            }
        }

        // 7 * 6
        private void generate_Standbutton_arr() {
            for (int i = 0; i < standButton_arr.Length; i++) {
                standButton_arr[i] = new Button();
                standButton_arr[i].Visible = true;

                if (i % 6 >= 3)
                    standButton_arr[i].Enabled = false;
                else
                    standButton_arr[i].Enabled = true;

                standButton_arr[i].Size = new Size(50, 50);
                standButton_arr[i].Location = new Point(standButton_offset.X + i % 6 * standButton_arr[i].Size.Width,
                                                        standButton_offset.Y + i / 6 * standButton_arr[i].Size.Height);
                standButton_arr[i].Text = "";
                standButton_arr[i].Click += standButton_Click_prepare;
                this.Controls.Add(standButton_arr[i]);
            }
        }

        private void timerPrepare_Tick(object sender, EventArgs e) {
            timerCount_prepare--;
            if (timerCount_prepare <= 0) {
                timerPrepare.Enabled = false;
                timerZero_prepare();
            }
            timerLable.Text = $"{timerCount_prepare}";
        }

        private void timerZero_prepare() {
            // 0 stand for player1, 1 stand for player2
            int playerStatus = player1_ed ? 1 : 0;

            // there are some chesses didn't place
            for (int i = 0; i < players[playerStatus].isPlace.Length; i++) {
                if (!players[playerStatus].isPlace[i]) {
                    EventArgs e = new EventArgs();
                    chooseButton_Click(chess_chooseButton_prepare_all[playerStatus][i], e);

                    for (int j = playerStatus == 0 ? 0 : 5;
                        j < standButton_arr.Length; j += 6) {

                        if (standButton_arr[j].Text == "") {
                            standButton_Click_prepare(standButton_arr[j], e);
                            break;
                        }
                    }
                }
            }
            if (!player1_ed) {

                // turn to player2
                timerPrepare.Enabled = true;
                timerCount_prepare = 10;
                timerLable.Text = $"{timerCount_prepare}";

                for (int i = 0; i < standButton_arr.Length; i++) {
                    if (i % 6 >= 3)
                        standButton_arr[i].Enabled = true;
                    else
                        standButton_arr[i].Enabled = false;
                }

                foreach (var b in chess_prepare_p1) {
                    b.Enabled = false;
                }
                foreach (var b in chess_prepare_p2) {
                    b.Enabled = true;
                }
                chess_prepare_p2[0].Checked = true;

                choose_label_p2.Visible = true;

                player1_ed = true;

            }
            else {
                player2_ed = true;
                timerPrepare.Enabled = false;
                timerCount_prepare = 0;
                timerLable.Text = $"{timerCount_prepare}";

                foreach (var b in standButton_arr) {
                    b.Click -= standButton_Click_prepare;
                }

                Form1_Battle();
            }

        }

        private void chooseButton_Click(object sender, EventArgs e) {
            RadioButton radButton = (RadioButton)sender;

            if (radButton.Location.X <= this.Size.Width / 2)
                choose_label[0].Text = radButton.Text.Substring(0, 2);
            else
                choose_label[1].Text = radButton.Text.Substring(0, 2);

        }

        private void standButton_Click_prepare(object sender, EventArgs e) {
            Button target = (Button)sender;
            int playerStatus = player1_ed ? 1 : 0;

            target.BackColor = players_color[playerStatus];
            target.Text = choose_label[playerStatus].Text;
            target.Enabled = false;

            int index_chessNow = chessTypeNameToIndex(choose_label[playerStatus].Text);
            chess_chooseButton_prepare_all[playerStatus][index_chessNow].Enabled = false;

            chess_chooseButton_prepare_all[playerStatus][index_chessNow].Text =
                chess_chooseButton_prepare_all[playerStatus][index_chessNow].Text.Replace('1', '0');

            players[playerStatus].isPlace[index_chessNow] = true;
            players[playerStatus].chess[index_chessNow].loc = findStandButtonPos(target);

            int countFalse = 0;
            foreach (var b in chess_chooseButton_prepare_all[playerStatus]) {
                if (b.Enabled) {
                    b.Checked = true;
                    choose_label[playerStatus].Text = b.Text.Substring(0, 2);

                    break;
                }
                countFalse++;
            }

            if (countFalse >= 3 && timerCount_prepare > 0) {
                timerZero_prepare();
            }
        }

        private Point findStandButtonPos(Button sender) {
            Point loc = new Point();
            for (int i = 0; i < standButton_arr.Length; i++) {
                if (standButton_arr[i] == sender) {
                    loc.X = i % 6;
                    loc.Y = i / 6;
                }
            }

            return loc;
        }

        private void showChessInfo(int index_chessType, int playerStatus) {
            chessInfo[playerStatus].Text =
                        $"HP: {players[playerStatus].chess[index_chessType].hp}\n" +
                        $"MP: {players[playerStatus].chess[index_chessType].mp}\n" +
                        $"ATK: {players[playerStatus].chess[index_chessType].atk}\n" +
                        $"ATK Range: {players[playerStatus].chess[index_chessType].atkRange}\n" +
                        $"MOVE Range: {players[playerStatus].chess[index_chessType].moveRange}";
        }

        private void AttackInstructionButton_Click(object sender, EventArgs e) {

            int playerStatus = isPlayer1Battle ? 0 : 1;

            players[playerStatus].chess[player_round].falsizeInstruction();
            players[playerStatus].chess[player_round].isAttack = true;
        }
        private void MoveInstructionButton_Click(object sender, EventArgs e) {
            int playerStatus = isPlayer1Battle ? 0 : 1;

            players[playerStatus].chess[player_round].falsizeInstruction();
            players[playerStatus].chess[player_round].isMove = true;
        }
        private void SkillInstructionButton_Click(object sender, EventArgs e) {
            int playerStatus = isPlayer1Battle ? 0 : 1;

            players[playerStatus].chess[player_round].falsizeInstruction();
            players[playerStatus].chess[player_round].isSkill = true;
        }
        private void IdleInstructionButton_Click(object sender, EventArgs e) {
            int playerStatus = isPlayer1Battle ? 0 : 1;

            players[playerStatus].chess[player_round].falsizeInstruction();
            players[playerStatus].chess[player_round].isIdle = true;

            if (players[playerStatus].carryInstruction(player_round, playerStatus, sender) == 3) {
                increasePlayer_round(players[playerStatus], false);
                next_chess();
            }
        }

        private void standButton_Click_battle(object sender, EventArgs e) {
            Button sender_button = (Button)sender;

            int playerStatus = isPlayer1Battle ? 0 : 1;
            int otherStatus = isPlayer1Battle ? 1 : 0;

            if (finishButton[playerStatus].Enabled == true)
                return;

                // save for move
                Point chessBeforeMove = players[playerStatus].chess[player_round].loc;

            int index_instruction = players[playerStatus].carryInstruction(player_round, playerStatus, sender);
            switch (index_instruction) {
                case 0:
                case 2:
                    int index_otherChessType = chessTypeNameToIndex(sender_button.Text);

                    choose_label[otherStatus].Visible = true;
                    choose_label[otherStatus].Text = chessTypeName[index_otherChessType];

                    chessInfo[otherStatus].Visible = true;
                    showChessInfo(index_otherChessType, otherStatus);

                    if (players[otherStatus].chess[index_otherChessType].isDead) {
                        sender_button.BackColor = Color.White;
                        sender_button.Text = "";
                    }
                    break;

                case 1:
                    choose_label[otherStatus].Visible = false;
                    chessInfo[otherStatus].Visible = false;

                    int index = chessBeforeMove.X + chessBeforeMove.Y * 6;
                    standButton_arr[index].BackColor = Color.White;
                    standButton_arr[index].Text = "";
                    break;

                default:
                    return;
            }


            if (players[otherStatus].isLose) {
                string player = playerStatus == 0 ? "P1" : "P2";
                MessageBox.Show($"{player}贏了");
                this.Close();
            }

            increasePlayer_round(players[playerStatus], false);
            next_chess();
        }
        private void finishButton_Click(object sender, EventArgs e) {
            int playerStatus = isPlayer1Battle ? 0 : 1;
            int otherStatus = isPlayer1Battle ? 1 : 0;

            title.Text = battle_title[otherStatus];

            int index_canUseChess = players[otherStatus].canUseChess(0);
            choose_label[otherStatus].Text = chessTypeName[index_canUseChess];
            showChessInfo(index_canUseChess, otherStatus);

            choose_label[otherStatus].Visible = true;
            choose_label[playerStatus].Visible = false;

            chessInfo[otherStatus].Visible = true;
            chessInfo[playerStatus].Visible = false;

            finishButton[playerStatus].Enabled = false;

            for (int i = 0; i < battleInstructionButton.GetLength(1); i++) {
                battleInstructionButton[playerStatus, i].Enabled = false;
                battleInstructionButton[otherStatus, i].Enabled = true;
            }

            increasePlayer_round(players[otherStatus], true);
            isPlayer1Battle = !isPlayer1Battle;

        }

        // -1 stand for Error
        public static int chessTypeNameToIndex(string chessType) {
            for (int i = 0; i < chessTypeName.Length; i++) {
                if (chessTypeName[i] == chessType)
                    return i;
            }
            return -1;
        }

        private void next_chess() {
            int playerStatus = isPlayer1Battle ? 0 : 1;

            int indexNow = chessTypeNameToIndex(choose_label[playerStatus].Text);
            int index_canUseChess = players[playerStatus].canUseChess(indexNow + 1);
            if (index_canUseChess == -1) {
                for (int i = 0; i < battleInstructionButton.GetLength(1); i++) {
                    battleInstructionButton[playerStatus, i].Enabled = false;
                }
                finishButton[playerStatus].Enabled = true;
                return;
            }

            choose_label[playerStatus].Text = chessTypeName[index_canUseChess];

            showChessInfo(index_canUseChess, playerStatus);
        }

        private void increasePlayer_round(Player player, bool init) {
            if (init)
                player_round = -1;
            do {
                player_round++;
                if (player_round > 2)
                    break;
            }
            while (player.isDead[player_round]);
        }

    }

    public class Player {
        public Chess[] chess;

        public Worrior worrior;
        public Wizard wizard;
        public Ranger ranger;

        // 1.worrior 2.wizard 3.ranger
        public bool[] isPlace;
        public bool[] isDead;
        public bool isLose = false;
        public int numOfChess = 3;

        public Player(Color teamColor, string worrior_name, string wizard_name, string ranger_name) {
            isPlace = new bool[3] { false, false, false };
            isDead = new bool[3] { false, false, false };

            worrior = new Worrior(teamColor, worrior_name);
            wizard = new Wizard(teamColor, wizard_name);
            ranger = new Ranger(teamColor, ranger_name);

            chess = new Chess[3] { worrior, wizard, ranger };
        }

        /** 
         * sender is a StandButton
         * return a status -1.nothing 0.attack 1.move 2.skill 3.idle
         */
        public int carryInstruction(int player_round, int otherStatus, Object sender) {
            Chess pawn = chess[player_round];
            Button sender_button = (Button)sender;
            bool keepStatus;
            if (pawn.isAttack) {
                keepStatus = pawn.attack(sender);
                if (keepStatus) {
                    checkDead(otherStatus);
                    return 0;
                }
            }
            else if (pawn.isMove) {
                keepStatus = pawn.move(sender);
                if (keepStatus) {
                    return 1;
                }
            }
            else if (pawn.isSkill) {
                keepStatus = pawn.Skill(sender);
                if (keepStatus) {
                    checkDead(otherStatus);
                    return 2;
                }
            }
            else if (pawn.isIdle) {
                return 3;
            }

            return -1;
        }

        private void checkDead(int playerStatus) {
            int otherStatus = playerStatus == 0 ? 1 : 0;
            Player other = Form1.players[otherStatus];

            int countDead = 0;
            for (int i = 0; i < other.chess.Length; i++) {
                if (other.chess[i].isDead) {
                    countDead++;
                    other.isDead[i] = true;
                }
            }
            if (countDead >= 3)
                other.isLose = true;
        }

        /**
         * search from index
         * return index, -1 stand for none
         */
        public int canUseChess(int index) {
            for (int i = index; i < isDead.Length; i++) {
                if (!isDead[i]) {
                    return i;
                }
            }

            return -1;
        }
    }
    public class Chess {
        public string name;
        public Color teamColor;
        public int hp;
        public int mp;
        public int atk;
        public int atkRange;
        public int moveRange;
        public Point loc;

        public bool isPlace;
        public bool isDead;

        public bool isAttack;
        public bool isMove;
        public bool isSkill;
        public bool isIdle;
        public Chess(int HP, int MP, int ATK, int ATKRange, int MoveRange, Color team_color, string chessName) {
            name = chessName;
            hp = HP;
            mp = MP;
            atk = ATK;
            atkRange = ATKRange;
            moveRange = MoveRange;
            loc = new Point();

            isDead = false;
            isPlace = false;

            isAttack = false;
            isMove = false;
            isSkill = false;
            isIdle = false;

            teamColor = team_color;
        }

        public virtual void falsizeInstruction() {
            isAttack = false;
            isMove = false;
            isSkill = false;
            isIdle = false;
        }

        // sender is a StandButton
        public virtual bool attack(Object sender) {
            Button sender_button = (Button)sender;

            Point senderLoc = determineSender_button_loc(sender_button);

            if (sender_button.Text == "" || sender_button.BackColor == teamColor) {
                return false;
            }

            // attack
            if ((loc.X == senderLoc.X && Math.Abs(loc.Y - senderLoc.Y) <= atkRange) ||
                loc.Y == senderLoc.Y && Math.Abs(loc.X - senderLoc.X) <= atkRange) {
                int otherStatus;
                for (otherStatus = 0; otherStatus < Form1.players_color.Length; otherStatus++) {
                    if (Form1.players_color[otherStatus] != teamColor)
                        break;
                }

                int index_senderChessType = Form1.chessTypeNameToIndex(sender_button.Text);

                Form1.players[otherStatus].chess[index_senderChessType].hp -= atk;
                if (Form1.players[otherStatus].chess[index_senderChessType].hp <= 0) {
                    Form1.players[otherStatus].chess[index_senderChessType].hp = 0;
                    Form1.players[otherStatus].chess[index_senderChessType].isDead = true;
                }

                return true;
            }

            MessageBox.Show("超出攻擊範圍");
            // leave for debug
            //MessageBox.Show($"{senderLoc.X}\n{senderLoc.Y}\n{loc.X}\n{loc.Y}");
            return false;

        }

        // sender is a StandButton
        public virtual bool move(Object sender) {
            Button sender_button = (Button)sender;

            Point senderLoc = determineSender_button_loc(sender_button);

            if (sender_button.BackColor == Form1.players_color[0] || sender_button.BackColor == Form1.players_color[1]) {
                return false;
            }

            // move
            if ((loc.X == senderLoc.X && Math.Abs(loc.Y - senderLoc.Y) <= moveRange) ||
                loc.Y == senderLoc.Y && Math.Abs(loc.X - senderLoc.X) <= moveRange) {
                loc = senderLoc;
                sender_button.BackColor = teamColor;
                sender_button.Text = name;

                return true;
            }

            MessageBox.Show("超出移動範圍");
            return false;
        }
        public virtual bool Skill(Object sender) {
            if (mp >= 10)
                this.mp -= 10;
            else
                return false;

            return true;
        }

        private Point determineSender_button_loc(Button sender_button) {
            Point senderLoc = new Point();
            senderLoc.X = (sender_button.Location.X - Form1.standButton_offset.X) / sender_button.Size.Width;
            senderLoc.Y = (sender_button.Location.Y - Form1.standButton_offset.Y) / sender_button.Size.Height;
            return senderLoc;
        }
    }

    public class Worrior : Chess {
        public Worrior(Color teamColor, string name) : base(100, 15, 30, 1, 2, teamColor, name) {

        }
        public override bool Skill(Object sender) {
            bool keepStatus = base.Skill(sender);
            if (keepStatus == false) {
                return false;
            }

            keepStatus = attack(sender);
            if (keepStatus) {
                hp += atk / 2;
            }
            else {
                mp += 10;
            }

            return keepStatus;
        }
    }

    public class Wizard : Chess {
        public Wizard(Color teamColor, string name) : base(70, 25, 20, 2, 2, teamColor, name) {

        }
        public override bool Skill(Object sender) {
            bool keepStatus = base.Skill(sender);
            if (keepStatus == false) {
                return false;
            }

            atk *= 2;
            keepStatus = attack(sender);
            atk /= 2;

            if (keepStatus==false) {
                mp += 10;
            }

            return keepStatus;

        }
    }
    public class Ranger : Chess {
        public Ranger(Color teamColor, string name) : base(90, 10, 30, 3, 1, teamColor, name) {

        }
        public override bool Skill(Object sender) {
            bool keepStatus = base.Skill(sender);
            if (keepStatus == false) {
                return false;
            }

            atkRange++;
            keepStatus = attack(sender);
            if (keepStatus==false) {
                mp += 10;
                atkRange--;
            }

            return keepStatus;
        }
    }
}
