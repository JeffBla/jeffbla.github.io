﻿namespace warChess_simple {
    partial class Form1 {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.startButton = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Label();
            this.timerPrepare = new System.Windows.Forms.Timer(this.components);
            this.timerLable = new System.Windows.Forms.Label();
            this.player1_label = new System.Windows.Forms.Label();
            this.player2_label = new System.Windows.Forms.Label();
            this.worriorButton_prepare_p1 = new System.Windows.Forms.RadioButton();
            this.rangerButton_prepare_p1 = new System.Windows.Forms.RadioButton();
            this.wizardButton_prepare_p1 = new System.Windows.Forms.RadioButton();
            this.wizardButton_prepare_p2 = new System.Windows.Forms.RadioButton();
            this.rangerButton_prepare_p2 = new System.Windows.Forms.RadioButton();
            this.worriorButton_prepare_p2 = new System.Windows.Forms.RadioButton();
            this.choose_label_p1 = new System.Windows.Forms.Label();
            this.choose_label_p2 = new System.Windows.Forms.Label();
            this.chessInfo_p1 = new System.Windows.Forms.Label();
            this.chessInfo_p2 = new System.Windows.Forms.Label();
            this.attackButton_p1 = new System.Windows.Forms.Button();
            this.moveButton_p1 = new System.Windows.Forms.Button();
            this.skillButton_p1 = new System.Windows.Forms.Button();
            this.idleButton_p1 = new System.Windows.Forms.Button();
            this.idleButton_p2 = new System.Windows.Forms.Button();
            this.skillButton_p2 = new System.Windows.Forms.Button();
            this.moveButton_p2 = new System.Windows.Forms.Button();
            this.attackButton_p2 = new System.Windows.Forms.Button();
            this.finishButton_p1 = new System.Windows.Forms.Button();
            this.finishButton_p2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(473, 255);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(227, 139);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "開始遊戲";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.title.Location = new System.Drawing.Point(506, 42);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(137, 30);
            this.title.TabIndex = 1;
            this.title.Text = "準備階段";
            // 
            // timerPrepare
            // 
            this.timerPrepare.Interval = 1000;
            this.timerPrepare.Tick += new System.EventHandler(this.timerPrepare_Tick);
            // 
            // timerLable
            // 
            this.timerLable.AutoSize = true;
            this.timerLable.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.timerLable.Location = new System.Drawing.Point(552, 93);
            this.timerLable.Name = "timerLable";
            this.timerLable.Size = new System.Drawing.Size(45, 30);
            this.timerLable.TabIndex = 2;
            this.timerLable.Text = "10";
            // 
            // player1_label
            // 
            this.player1_label.AutoSize = true;
            this.player1_label.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.player1_label.Location = new System.Drawing.Point(152, 93);
            this.player1_label.Name = "player1_label";
            this.player1_label.Size = new System.Drawing.Size(45, 30);
            this.player1_label.TabIndex = 3;
            this.player1_label.Text = "P1";
            // 
            // player2_label
            // 
            this.player2_label.AutoSize = true;
            this.player2_label.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.player2_label.Location = new System.Drawing.Point(996, 93);
            this.player2_label.Name = "player2_label";
            this.player2_label.Size = new System.Drawing.Size(45, 30);
            this.player2_label.TabIndex = 4;
            this.player2_label.Text = "P2";
            // 
            // worriorButton_prepare_p1
            // 
            this.worriorButton_prepare_p1.AutoSize = true;
            this.worriorButton_prepare_p1.Location = new System.Drawing.Point(143, 218);
            this.worriorButton_prepare_p1.Name = "worriorButton_prepare_p1";
            this.worriorButton_prepare_p1.Size = new System.Drawing.Size(88, 19);
            this.worriorButton_prepare_p1.TabIndex = 5;
            this.worriorButton_prepare_p1.Text = "戰士: 1顆";
            this.worriorButton_prepare_p1.UseVisualStyleBackColor = true;
            // 
            // rangerButton_prepare_p1
            // 
            this.rangerButton_prepare_p1.AutoSize = true;
            this.rangerButton_prepare_p1.Location = new System.Drawing.Point(143, 292);
            this.rangerButton_prepare_p1.Name = "rangerButton_prepare_p1";
            this.rangerButton_prepare_p1.Size = new System.Drawing.Size(88, 19);
            this.rangerButton_prepare_p1.TabIndex = 6;
            this.rangerButton_prepare_p1.TabStop = true;
            this.rangerButton_prepare_p1.Text = "遊俠: 1顆";
            this.rangerButton_prepare_p1.UseVisualStyleBackColor = true;
            this.rangerButton_prepare_p1.Click += new System.EventHandler(this.chooseButton_Click);
            // 
            // wizardButton_prepare_p1
            // 
            this.wizardButton_prepare_p1.AutoSize = true;
            this.wizardButton_prepare_p1.Location = new System.Drawing.Point(143, 255);
            this.wizardButton_prepare_p1.Name = "wizardButton_prepare_p1";
            this.wizardButton_prepare_p1.Size = new System.Drawing.Size(88, 19);
            this.wizardButton_prepare_p1.TabIndex = 7;
            this.wizardButton_prepare_p1.TabStop = true;
            this.wizardButton_prepare_p1.Text = "法師: 1顆";
            this.wizardButton_prepare_p1.UseVisualStyleBackColor = true;
            this.wizardButton_prepare_p1.Click += new System.EventHandler(this.chooseButton_Click);
            // 
            // wizardButton_prepare_p2
            // 
            this.wizardButton_prepare_p2.AutoSize = true;
            this.wizardButton_prepare_p2.Location = new System.Drawing.Point(969, 255);
            this.wizardButton_prepare_p2.Name = "wizardButton_prepare_p2";
            this.wizardButton_prepare_p2.Size = new System.Drawing.Size(88, 19);
            this.wizardButton_prepare_p2.TabIndex = 10;
            this.wizardButton_prepare_p2.TabStop = true;
            this.wizardButton_prepare_p2.Text = "法師: 1顆";
            this.wizardButton_prepare_p2.UseVisualStyleBackColor = true;
            this.wizardButton_prepare_p2.Click += new System.EventHandler(this.chooseButton_Click);
            // 
            // rangerButton_prepare_p2
            // 
            this.rangerButton_prepare_p2.AutoSize = true;
            this.rangerButton_prepare_p2.Location = new System.Drawing.Point(969, 292);
            this.rangerButton_prepare_p2.Name = "rangerButton_prepare_p2";
            this.rangerButton_prepare_p2.Size = new System.Drawing.Size(88, 19);
            this.rangerButton_prepare_p2.TabIndex = 9;
            this.rangerButton_prepare_p2.TabStop = true;
            this.rangerButton_prepare_p2.Text = "遊俠: 1顆";
            this.rangerButton_prepare_p2.UseVisualStyleBackColor = true;
            this.rangerButton_prepare_p2.Click += new System.EventHandler(this.chooseButton_Click);
            // 
            // worriorButton_prepare_p2
            // 
            this.worriorButton_prepare_p2.AutoSize = true;
            this.worriorButton_prepare_p2.Location = new System.Drawing.Point(969, 218);
            this.worriorButton_prepare_p2.Name = "worriorButton_prepare_p2";
            this.worriorButton_prepare_p2.Size = new System.Drawing.Size(88, 19);
            this.worriorButton_prepare_p2.TabIndex = 8;
            this.worriorButton_prepare_p2.TabStop = true;
            this.worriorButton_prepare_p2.Text = "戰士: 1顆";
            this.worriorButton_prepare_p2.UseVisualStyleBackColor = true;
            this.worriorButton_prepare_p2.Click += new System.EventHandler(this.chooseButton_Click);
            // 
            // choose_label_p1
            // 
            this.choose_label_p1.AutoSize = true;
            this.choose_label_p1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.choose_label_p1.Location = new System.Drawing.Point(138, 150);
            this.choose_label_p1.Name = "choose_label_p1";
            this.choose_label_p1.Size = new System.Drawing.Size(73, 30);
            this.choose_label_p1.TabIndex = 11;
            this.choose_label_p1.Text = "戰士";
            // 
            // choose_label_p2
            // 
            this.choose_label_p2.AutoSize = true;
            this.choose_label_p2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.choose_label_p2.Location = new System.Drawing.Point(984, 150);
            this.choose_label_p2.Name = "choose_label_p2";
            this.choose_label_p2.Size = new System.Drawing.Size(73, 30);
            this.choose_label_p2.TabIndex = 12;
            this.choose_label_p2.Text = "戰士";
            // 
            // chessInfo_p1
            // 
            this.chessInfo_p1.AutoSize = true;
            this.chessInfo_p1.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chessInfo_p1.Location = new System.Drawing.Point(119, 206);
            this.chessInfo_p1.Name = "chessInfo_p1";
            this.chessInfo_p1.Size = new System.Drawing.Size(46, 17);
            this.chessInfo_p1.TabIndex = 14;
            this.chessInfo_p1.Text = "label2";
            // 
            // chessInfo_p2
            // 
            this.chessInfo_p2.AutoSize = true;
            this.chessInfo_p2.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chessInfo_p2.Location = new System.Drawing.Point(965, 206);
            this.chessInfo_p2.Name = "chessInfo_p2";
            this.chessInfo_p2.Size = new System.Drawing.Size(46, 17);
            this.chessInfo_p2.TabIndex = 15;
            this.chessInfo_p2.Text = "label2";
            // 
            // attackButton_p1
            // 
            this.attackButton_p1.Location = new System.Drawing.Point(90, 354);
            this.attackButton_p1.Name = "attackButton_p1";
            this.attackButton_p1.Size = new System.Drawing.Size(75, 55);
            this.attackButton_p1.TabIndex = 16;
            this.attackButton_p1.Text = "攻擊";
            this.attackButton_p1.UseVisualStyleBackColor = true;
            this.attackButton_p1.Click += new System.EventHandler(this.AttackInstructionButton_Click);
            // 
            // moveButton_p1
            // 
            this.moveButton_p1.Location = new System.Drawing.Point(189, 352);
            this.moveButton_p1.Name = "moveButton_p1";
            this.moveButton_p1.Size = new System.Drawing.Size(75, 55);
            this.moveButton_p1.TabIndex = 17;
            this.moveButton_p1.Text = "移動";
            this.moveButton_p1.UseVisualStyleBackColor = true;
            this.moveButton_p1.Click += new System.EventHandler(this.MoveInstructionButton_Click);
            // 
            // skillButton_p1
            // 
            this.skillButton_p1.Location = new System.Drawing.Point(90, 431);
            this.skillButton_p1.Name = "skillButton_p1";
            this.skillButton_p1.Size = new System.Drawing.Size(75, 55);
            this.skillButton_p1.TabIndex = 18;
            this.skillButton_p1.Text = "技能";
            this.skillButton_p1.UseVisualStyleBackColor = true;
            this.skillButton_p1.Click += new System.EventHandler(this.SkillInstructionButton_Click);
            // 
            // idleButton_p1
            // 
            this.idleButton_p1.Location = new System.Drawing.Point(189, 431);
            this.idleButton_p1.Name = "idleButton_p1";
            this.idleButton_p1.Size = new System.Drawing.Size(75, 55);
            this.idleButton_p1.TabIndex = 19;
            this.idleButton_p1.Text = "待機";
            this.idleButton_p1.UseVisualStyleBackColor = true;
            this.idleButton_p1.Click += new System.EventHandler(this.IdleInstructionButton_Click);
            // 
            // idleButton_p2
            // 
            this.idleButton_p2.Location = new System.Drawing.Point(1024, 431);
            this.idleButton_p2.Name = "idleButton_p2";
            this.idleButton_p2.Size = new System.Drawing.Size(75, 55);
            this.idleButton_p2.TabIndex = 23;
            this.idleButton_p2.Text = "待機";
            this.idleButton_p2.UseVisualStyleBackColor = true;
            this.idleButton_p2.Click += new System.EventHandler(this.IdleInstructionButton_Click);
            // 
            // skillButton_p2
            // 
            this.skillButton_p2.Location = new System.Drawing.Point(925, 431);
            this.skillButton_p2.Name = "skillButton_p2";
            this.skillButton_p2.Size = new System.Drawing.Size(75, 55);
            this.skillButton_p2.TabIndex = 22;
            this.skillButton_p2.Text = "技能";
            this.skillButton_p2.UseVisualStyleBackColor = true;
            this.skillButton_p2.Click += new System.EventHandler(this.SkillInstructionButton_Click);
            // 
            // moveButton_p2
            // 
            this.moveButton_p2.Location = new System.Drawing.Point(1024, 354);
            this.moveButton_p2.Name = "moveButton_p2";
            this.moveButton_p2.Size = new System.Drawing.Size(75, 55);
            this.moveButton_p2.TabIndex = 21;
            this.moveButton_p2.Text = "移動";
            this.moveButton_p2.UseVisualStyleBackColor = true;
            this.moveButton_p2.Click += new System.EventHandler(this.MoveInstructionButton_Click);
            // 
            // attackButton_p2
            // 
            this.attackButton_p2.Location = new System.Drawing.Point(925, 354);
            this.attackButton_p2.Name = "attackButton_p2";
            this.attackButton_p2.Size = new System.Drawing.Size(75, 55);
            this.attackButton_p2.TabIndex = 20;
            this.attackButton_p2.Text = "攻擊";
            this.attackButton_p2.UseVisualStyleBackColor = true;
            this.attackButton_p2.Click += new System.EventHandler(this.AttackInstructionButton_Click);
            // 
            // finishButton_p1
            // 
            this.finishButton_p1.Location = new System.Drawing.Point(90, 492);
            this.finishButton_p1.Name = "finishButton_p1";
            this.finishButton_p1.Size = new System.Drawing.Size(174, 55);
            this.finishButton_p1.TabIndex = 24;
            this.finishButton_p1.Text = "結束";
            this.finishButton_p1.UseVisualStyleBackColor = true;
            this.finishButton_p1.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // finishButton_p2
            // 
            this.finishButton_p2.Location = new System.Drawing.Point(925, 502);
            this.finishButton_p2.Name = "finishButton_p2";
            this.finishButton_p2.Size = new System.Drawing.Size(174, 55);
            this.finishButton_p2.TabIndex = 25;
            this.finishButton_p2.Text = "結束";
            this.finishButton_p2.UseVisualStyleBackColor = true;
            this.finishButton_p2.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 678);
            this.Controls.Add(this.finishButton_p2);
            this.Controls.Add(this.finishButton_p1);
            this.Controls.Add(this.idleButton_p2);
            this.Controls.Add(this.skillButton_p2);
            this.Controls.Add(this.moveButton_p2);
            this.Controls.Add(this.attackButton_p2);
            this.Controls.Add(this.idleButton_p1);
            this.Controls.Add(this.skillButton_p1);
            this.Controls.Add(this.moveButton_p1);
            this.Controls.Add(this.attackButton_p1);
            this.Controls.Add(this.chessInfo_p2);
            this.Controls.Add(this.chessInfo_p1);
            this.Controls.Add(this.choose_label_p2);
            this.Controls.Add(this.choose_label_p1);
            this.Controls.Add(this.wizardButton_prepare_p2);
            this.Controls.Add(this.rangerButton_prepare_p2);
            this.Controls.Add(this.worriorButton_prepare_p2);
            this.Controls.Add(this.wizardButton_prepare_p1);
            this.Controls.Add(this.rangerButton_prepare_p1);
            this.Controls.Add(this.worriorButton_prepare_p1);
            this.Controls.Add(this.player2_label);
            this.Controls.Add(this.player1_label);
            this.Controls.Add(this.timerLable);
            this.Controls.Add(this.title);
            this.Controls.Add(this.startButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Timer timerPrepare;
        private System.Windows.Forms.Label timerLable;
        private System.Windows.Forms.Label player1_label;
        private System.Windows.Forms.Label player2_label;
        private System.Windows.Forms.RadioButton worriorButton_prepare_p1;
        private System.Windows.Forms.RadioButton rangerButton_prepare_p1;
        private System.Windows.Forms.RadioButton wizardButton_prepare_p1;
        private System.Windows.Forms.RadioButton wizardButton_prepare_p2;
        private System.Windows.Forms.RadioButton rangerButton_prepare_p2;
        private System.Windows.Forms.RadioButton worriorButton_prepare_p2;
        private System.Windows.Forms.Label choose_label_p1;
        private System.Windows.Forms.Label choose_label_p2;
        private System.Windows.Forms.Label chessInfo_p1;
        private System.Windows.Forms.Label chessInfo_p2;
        private System.Windows.Forms.Button attackButton_p1;
        private System.Windows.Forms.Button moveButton_p1;
        private System.Windows.Forms.Button skillButton_p1;
        private System.Windows.Forms.Button idleButton_p1;
        private System.Windows.Forms.Button idleButton_p2;
        private System.Windows.Forms.Button skillButton_p2;
        private System.Windows.Forms.Button moveButton_p2;
        private System.Windows.Forms.Button attackButton_p2;
        private System.Windows.Forms.Button finishButton_p1;
        private System.Windows.Forms.Button finishButton_p2;
    }
}

