#include <stdio.h>
#include <string.h>

#include "Fheap_implement.h"
#include "hashTable_linkedlist.h"

int main() {
    char command[10];
    int x, val, y;
    Fheap fheap = createFheap();
    HashTable_NumType_linkedList hashTable = createHashTable_NumType_linkedList();
    for (;;) {
        scanf("%s", command);
        fflush(stdout);
        if (strcmp(command, "insert") == 0) {
            scanf("%d %d", &x, &val);
            insert_Fheap(fheap, x, val, hashTable);
        }
        else if (strcmp(command, "extract") == 0) {
            FheapNode *ans = deleteMin_Fheap(fheap, hashTable);
            if (ans != NULL) {
                printf("(%d)%d\n", ans->key, ans->val);
                free(ans);
            }
            ans = NULL;
        }
        else if (strcmp(command, "delete") == 0) {
            scanf("%d %d", &x, &val);
            delete_Fheap(fheap, x, val, hashTable);
        }
        else if (strcmp(command, "decrease") == 0) {
            scanf("%d %d %d", &x, &val, &y);
            decreaseKey_Fheap(fheap, x, val, y, hashTable);
        }
        else if (strcmp(command, "quit") == 0) {
            return 0;
        }
    }
}
