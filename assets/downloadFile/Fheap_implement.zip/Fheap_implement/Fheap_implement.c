#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>

#include "Fheap_implement.h"
#include "hashTable_linkedlist.h"

#define swap(x, y, tmp) {tmp = x; x = y; y = tmp;}

FheapNode *doublyLinkedListInsert_FheapNode(FheapNode *target, FheapNode *nodeToInsert) {
    nodeToInsert->right = target->right;
    nodeToInsert->left = target;
    target->right->left = nodeToInsert;
    target->right = nodeToInsert;
    return nodeToInsert;
}

bool isEmpty_Fheap(Fheap fheap) {
    if (fheap->min == NULL)
        return true;
    return false;
}

FheapNode *createFheapNode() {
    FheapNode *new_node = malloc(sizeof(*new_node));
    new_node->key = 0;
    new_node->val = 0;
    new_node->degree = 0;
    new_node->right = new_node;
    new_node->left = new_node;
    new_node->child = NULL;
    new_node->parent = NULL;
    new_node->childCut = false;
    return new_node;
}

Fheap createFheap() {
    Fheap fheap = malloc(sizeof(*fheap));
    fheap->sz = 0;
    fheap->min = NULL;
    return fheap;
}

Fheap insert_Fheap(Fheap fheap, KeyType_Fheap key, ValType_Fheap val, HashTable_NumType_linkedList hashTable) {
    FheapNode *new_node = createFheapNode();
    new_node->key = key;
    new_node->val = val;
    if (isEmpty_Fheap(fheap)) {
        fheap->min = new_node;
    }
    else {
        doublyLinkedListInsert_FheapNode(fheap->min, new_node);
        if (new_node->key < fheap->min->key)
            fheap->min = new_node;
        else if (new_node->key == fheap->min->key)
            if (new_node->val < fheap->min->val)
                fheap->min = new_node;
    }
    fheap->sz++;
    insert_HashTable_NumType_linkedList(hashTable, key, val, new_node);

    return fheap;
}

FheapNode *combineNode_Fheap(FheapNode **arr, FheapNode *parent) {
    size_t prev_degree;
    FheapNode *tmpForSwap, *child;
    while (arr[parent->degree] != NULL) {
        prev_degree = parent->degree;

        child = arr[parent->degree];
        if (parent->key > child->key) {
            swap(parent, child, tmpForSwap);
        }

        if (parent->degree == 0) {
            child->parent = parent;
            parent->child = child;

            child->right = child;
            child->left = child;
        }
        else {
            child->parent = parent;

            doublyLinkedListInsert_FheapNode(parent->child, child);
        }
        child->childCut = false;
        parent->degree++;

        arr[prev_degree] = NULL;
    }

    arr[parent->degree] = parent;
    return parent;
}

FheapNode *deleteMin_Fheap(Fheap fheap, HashTable_NumType_linkedList hashTable) {

    if(isEmpty_Fheap(fheap))
        return NULL;
    FheapNode *result = (FheapNode *) delete_HashTable_NumType_linkedList(hashTable, fheap->min->key, fheap->min->val);
    if (result == NULL) {
        fprintf(stdout, "ERROR from deleteMin_Fheap : Didn't exist the key value pair.\n");
        fflush(stdout);
        return NULL;
    }

    size_t arrSz = log10(fheap->sz) / log10(1.618) + 4;
    FheapNode **arr = calloc(arrSz, sizeof(FheapNode));
    // insert result's child
    FheapNode *curr = result->child;
    if (curr != NULL) {
        do {
            curr->parent = NULL;
            if (arr[curr->degree] != NULL) {
                combineNode_Fheap(arr, curr);
            }
            else {
                arr[curr->degree] = curr;
            }
            curr = curr->right;
        } while (curr != result->child);
    }
    // insert other min trees in top level;
    curr = result->right;
    while (curr != result) {
        FheapNode *tmp_right = curr->right;
        if (arr[curr->degree] != NULL) {
            combineNode_Fheap(arr, curr);
        }
        else {
            arr[curr->degree] = curr;
        }
        curr = tmp_right;
    }

    // combine all the min tree in arr
    FheapNode *head = NULL;
    for (int i = 0; i < arrSz; i++) {
        if (arr[i] != NULL) {
            if (head == NULL) {
                head = arr[i];

                head->right = head;
                head->left = head;
            }
            else {
                doublyLinkedListInsert_FheapNode(head, arr[i]);
                if (head->key > arr[i]->key)
                    head = arr[i];
                else if (head->key == arr[i]->key)
                    if (head->val > arr[i]->val)
                        head = arr[i];
            }
        }
    }
    fheap->min = head;
    free(arr);
    fheap->sz--;
    return result;
}

void cascadingCut_Fheap(Fheap fheap, FheapNode *curr) {
    FheapNode *parent, *left;
    // if curr == root -> pass
    while (curr->childCut == true && curr->parent != NULL) {
        parent = curr->parent;
        if (curr->right == curr)
            parent->child = NULL;
        else
            parent->child = curr->right;
        curr->parent = NULL;
        // handle sibling
        if (curr->right != curr) {
            left = curr->left;
            left->right = curr->right;
            curr->right->left = left;
        }
        // insert to top level
        doublyLinkedListInsert_FheapNode(fheap->min, curr);
        curr = parent;
    }
    curr->childCut = true;
}

FheapNode *delete_Fheap(Fheap fheap, KeyType_Fheap key, ValType_Fheap val, HashTable_NumType_linkedList hashTable) {
    if (fheap->min->key == key && fheap->min->val == val)
        return deleteMin_Fheap(fheap, hashTable);

    FheapNode *result = (FheapNode *) delete_HashTable_NumType_linkedList(hashTable, key, val);
    if (result == NULL) {
        fprintf(stderr, "ERROR from delete_Fheap : Didn't exist the key value pair.\n");
        fflush(stdout);
        return NULL;
    }
    // add the deleted child to fheap
    FheapNode *result_child = result->child;
    if (result_child != NULL) {
        do {
            result_child->parent = NULL;
            FheapNode *tmp_right = result_child->right;
            doublyLinkedListInsert_FheapNode(fheap->min, result_child);
            result_child = tmp_right;
        } while (result_child != result->child);
    }
    // handle the sibling
    FheapNode *tmp_left = result->left;
    tmp_left->right = result->right;
    result->right->left = tmp_left;

    // check the cascading cut
    if (result->parent != NULL) {
        FheapNode *result_parent = result->parent;
        result_parent->degree--;
        if (result->right == result) {
            result_parent->child = NULL;
        }
        else {
            result_parent->child = result->right;
        }
        cascadingCut_Fheap(fheap, result_parent);
    }

    fheap->sz--;
    return result;
}

FheapNode *decreaseKey_Fheap(Fheap fheap, KeyType_Fheap key, ValType_Fheap val, KeyType_Fheap minusBy,
                             HashTable_NumType_linkedList hashTable) {
    FheapNode *result = (FheapNode *) delete_HashTable_NumType_linkedList(hashTable, key, val);
    if (result == NULL) {
        fprintf(stderr, "ERROR from decreaseKey_Fheap : Didn't exist the key value pair.\n");
        fflush(stdout);
        return NULL;
    }

    result->key -= minusBy;
    // handle hashTable
    insert_HashTable_NumType_linkedList(hashTable, result->key, result->val, result);
    // check whether new_Key < parent
    if (result->parent != NULL && result->key < result->parent->key) {
        // handle sibling, parent and child
        if (result->right != result) {
            FheapNode *tmp_left = result->left;
            tmp_left->right = result->right;
            result->right->left = tmp_left;

            result->parent->child = result->right;
        }
        else
            result->parent->child = NULL;
        result->parent->degree--;
        cascadingCut_Fheap(fheap, result->parent);
        result->parent = NULL;
        doublyLinkedListInsert_FheapNode(fheap->min, result);
    }
    if (fheap->min != result) {
        if (result->key < fheap->min->key)
            fheap->min = result;
        else if (result->key == fheap->min->key)
            if (result->val < fheap->min->val)
                fheap->min = result;
    }

    return result;
}

