#ifndef FHEAP_IMPLEMENT_FHEAP_IMPLEMENT_H
#define FHEAP_IMPLEMENT_FHEAP_IMPLEMENT_H

#include <stdbool.h>

#include "hashTable_linkedlist.h"

typedef long long KeyType_Fheap;
typedef long long ValType_Fheap;
typedef struct fheapNode FheapNode;

struct fheapNode {
    size_t degree;
    KeyType_Fheap key;
    ValType_Fheap val;
    FheapNode *child, *right, *left, *parent;
    bool childCut;
};

typedef struct fheap {
    FheapNode *min;
    size_t sz;
} *Fheap;

bool isEmpty_Fheap(Fheap fheap);

FheapNode *createFheapNode();

Fheap createFheap();

Fheap insert_Fheap(Fheap fheap, KeyType_Fheap key, ValType_Fheap val, HashTable_NumType_linkedList hashTable);

FheapNode *deleteMin_Fheap(Fheap fheap, HashTable_NumType_linkedList hashTable);

FheapNode *delete_Fheap(Fheap fheap, KeyType_Fheap key, ValType_Fheap val, HashTable_NumType_linkedList hashTable);

FheapNode *decreaseKey_Fheap(Fheap fheap, KeyType_Fheap key, ValType_Fheap val, KeyType_Fheap minusby,
                          HashTable_NumType_linkedList hashTable);

#endif //FHEAP_IMPLEMENT_FHEAP_IMPLEMENT_H
