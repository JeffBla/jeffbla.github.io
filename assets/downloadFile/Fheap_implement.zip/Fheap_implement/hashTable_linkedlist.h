#ifndef HASHTABLE_IMPLEMENT1_HASHTABLE_LINKEDLIST_H
#define HASHTABLE_IMPLEMENT1_HASHTABLE_LINKEDLIST_H

#include <stdlib.h>
#include <stdbool.h>

#define DEFAULT_SIZE 100

typedef long long Key_Num_type;

typedef long long Value_Num_type;

typedef void *Ptr_type;

typedef struct listNode_NumType_linkedList ListNode_NumType_linkedList;

typedef struct hashTable_NumType_linkedList *HashTable_NumType_linkedList;

struct listNode_NumType_linkedList {
    Key_Num_type key;
    Value_Num_type val;
    Ptr_type ptr;
    ListNode_NumType_linkedList *next;
};

struct hashTable_NumType_linkedList {
    size_t sz;
    ListNode_NumType_linkedList **arr;
};

ListNode_NumType_linkedList *createListNode_NumType_linkedList();

HashTable_NumType_linkedList createHashTable_NumType_linkedList();

size_t hashFunc_NumType_linkedList(size_t maxSz, Key_Num_type key, Value_Num_type val);

HashTable_NumType_linkedList insert_HashTable_NumType_linkedList(HashTable_NumType_linkedList hashTable,
                                                                 Key_Num_type key, Value_Num_type val, Ptr_type ptr);

Ptr_type delete_HashTable_NumType_linkedList(HashTable_NumType_linkedList hashTable,
                                                   Key_Num_type key, Value_Num_type val);

Ptr_type search_HashTable_NumType_linkedList(HashTable_NumType_linkedList hashTable,
                                                   Key_Num_type key, Value_Num_type val);

#endif //HASHTABLE_IMPLEMENT1_HASHTABLE_LINKEDLIST_H
