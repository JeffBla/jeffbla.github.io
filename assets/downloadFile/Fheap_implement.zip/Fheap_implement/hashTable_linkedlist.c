#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "hashTable_linkedlist.h"

ListNode_NumType_linkedList *createListNode_NumType_linkedList() {
    ListNode_NumType_linkedList *new_node = malloc(sizeof(ListNode_NumType_linkedList));
    new_node->key = 0;
    new_node->val = 0;
    new_node->ptr = NULL;
    new_node->next = NULL;
    return new_node;
}

HashTable_NumType_linkedList createHashTable_NumType_linkedList() {
    HashTable_NumType_linkedList hashTable = malloc(sizeof(struct hashTable_NumType_linkedList));
    hashTable->sz = DEFAULT_SIZE;
    hashTable->arr = calloc(hashTable->sz,
                            sizeof(ListNode_NumType_linkedList) * hashTable->sz);

    return hashTable;
}

size_t hashFunc_NumType_linkedList(size_t maxSz, Key_Num_type key, Value_Num_type val) {
    long long ans = key * 3 + val;
    while (ans < 0) {
        ans += maxSz;
    }
    return ans % maxSz;
}

HashTable_NumType_linkedList
insert_HashTable_NumType_linkedList(HashTable_NumType_linkedList hashTable, Key_Num_type key, Value_Num_type val,
                                    Ptr_type ptr) {
    size_t index = hashFunc_NumType_linkedList(hashTable->sz, key, val);

    ListNode_NumType_linkedList *new_node = createListNode_NumType_linkedList();
    new_node->val = val;
    new_node->key = key;
    new_node->ptr = ptr;

    if (hashTable->arr[index] == NULL)
        hashTable->arr[index] = new_node;
    else {
        // overflow
        ListNode_NumType_linkedList *curr = hashTable->arr[index];
        if (curr->key > new_node->key) {
            new_node->next = curr;
            hashTable->arr[index] = new_node;
        }
        else {
            while (curr->next != NULL && curr->next->key < new_node->key)
                curr = curr->next;
            while (curr->next != NULL && curr->next->key == new_node->key && curr->next->val < new_node->val)
                curr = curr->next;
            new_node->next = curr->next;
            curr->next = new_node;
        }
    }
    return hashTable;
}

// NULL stand for find nothing
Ptr_type
delete_HashTable_NumType_linkedList(HashTable_NumType_linkedList hashTable, Key_Num_type key,
                                    Value_Num_type val) {
    void *result_ptr;
    // search key
    size_t index = hashFunc_NumType_linkedList(hashTable->sz, key, val);
    if (hashTable->arr[index] == NULL)
        return NULL;
    ListNode_NumType_linkedList *curr = hashTable->arr[index], *prev = NULL;
    while (curr != NULL && curr->key < key) {
        prev = curr;
        curr = curr->next;
    }
    while (curr != NULL && curr->key == key && curr->val != val) {
        prev = curr;
        curr = curr->next;
    }
    if (curr == NULL || curr->key != key || curr->val != val)
        return NULL;

    if (prev == NULL)
        hashTable->arr[index] = curr->next;
    else
        prev->next = curr->next;
    result_ptr = curr->ptr;
    free(curr);
    curr = NULL;
    return result_ptr;
}

// -1 stand for find nothing
Ptr_type search_HashTable_NumType_linkedList(HashTable_NumType_linkedList hashTable,
                                             Key_Num_type key, Value_Num_type val) {
    size_t index = hashFunc_NumType_linkedList(hashTable->sz, key, val);
    if (hashTable->arr[index] == NULL)
        return NULL;
    ListNode_NumType_linkedList *curr = hashTable->arr[index];
    while (curr != NULL && curr->key < key)
        curr = curr->next;
    while (curr != NULL && curr->key == key && curr->val < val)
        curr = curr->next;
    if (curr == NULL || curr->key != key || curr->val != val)
        return NULL;
    return curr->ptr;
}




